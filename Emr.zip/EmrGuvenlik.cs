using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace EmrGuvenlik
{
    static class Theme
    {
        public static readonly Color Side = ColorTranslator.FromHtml("#1B2A41");
        public static readonly Color SideHover = ColorTranslator.FromHtml("#263A57");
        public static readonly Color SideActive = ColorTranslator.FromHtml("#33507A");
        public static readonly Color SideText = ColorTranslator.FromHtml("#DBE4F0");
        public static readonly Color Bg = ColorTranslator.FromHtml("#F3F4F6");
        public static readonly Color Text = ColorTranslator.FromHtml("#1F2937");
        public static readonly Color Muted = ColorTranslator.FromHtml("#6B7280");
        public static readonly Color Accent = ColorTranslator.FromHtml("#0F766E");
        public static readonly Color Danger = ColorTranslator.FromHtml("#B42318");
        public static readonly Color Ok = ColorTranslator.FromHtml("#067647");
        public static readonly Color Warn = ColorTranslator.FromHtml("#B54708");
        public static readonly Color Line = ColorTranslator.FromHtml("#E5E7EB");
    }

    static class Native
    {
        [StructLayout(LayoutKind.Sequential)]
        public class MemStatus
        {
            public uint Length;
            public uint Load;
            public ulong TotalPhys, AvailPhys, TotalPage, AvailPage, TotalVirtual, AvailVirtual, AvailExt;
            public MemStatus() { Length = (uint)Marshal.SizeOf(typeof(MemStatus)); }
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GlobalMemoryStatusEx([In, Out] MemStatus s);
        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
        [DllImport("kernel32.dll")]
        public static extern bool CloseHandle(IntPtr h);
        [DllImport("psapi.dll")]
        public static extern bool EmptyWorkingSet(IntPtr h);
        [DllImport("user32.dll")]
        public static extern bool SetProcessDPIAware();
        [DllImport("kernel32.dll")]
        public static extern ulong GetTickCount64();

        public static MemStatus Status()
        {
            MemStatus s = new MemStatus();
            GlobalMemoryStatusEx(s);
            return s;
        }
    }

    static class Store
    {
        static readonly string Dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "EmrGuvenlik");
        static readonly string CfgFile = Path.Combine(Dir, "config.txt");
        static readonly string LogFile = Path.Combine(Dir, "olaylar.log");
        static readonly Dictionary<string, string> Cfg = new Dictionary<string, string>();

        public static void Load()
        {
            Cfg.Clear();
            try
            {
                foreach (string line in File.ReadAllLines(CfgFile, Encoding.UTF8))
                {
                    int i = line.IndexOf('=');
                    if (i > 0) Cfg[line.Substring(0, i)] = line.Substring(i + 1);
                }
            }
            catch { }
        }
        public static string Get(string k, string d)
        {
            string v;
            return Cfg.TryGetValue(k, out v) ? v : d;
        }
        public static void Set(string k, string v)
        {
            Cfg[k] = v;
            try
            {
                Directory.CreateDirectory(Dir);
                List<string> lines = new List<string>();
                foreach (KeyValuePair<string, string> p in Cfg) lines.Add(p.Key + "=" + p.Value);
                File.WriteAllLines(CfgFile, lines.ToArray(), Encoding.UTF8);
            }
            catch { }
        }
        public static void Log(string text)
        {
            try
            {
                Directory.CreateDirectory(Dir);
                File.AppendAllText(LogFile, DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss") + "  " + text + "\r\n", Encoding.UTF8);
            }
            catch { }
        }
        public static string[] ReadLog()
        {
            try { return File.ReadAllLines(LogFile, Encoding.UTF8); }
            catch { return new string[0]; }
        }
        public static void ClearLog()
        {
            try { File.Delete(LogFile); } catch { }
        }
    }

    class Assessment
    {
        public int Score;
        public string Label = "";
        public Color Color;
        public List<string> Tips = new List<string>();
    }

    static class Security
    {
        public const int MinLen = 8;
        const int Iter = 200000;
        static readonly RNGCryptoServiceProvider Rng = new RNGCryptoServiceProvider();
        static readonly HashSet<string> Common = new HashSet<string> {
            "123456", "12345678", "123456789", "password", "qwerty", "111111", "123123", "abc123",
            "iloveyou", "admin", "parola", "sifre", "şifre", "galatasaray", "fenerbahce", "besiktas",
            "trabzonspor", "istanbul", "ankara", "türkiye", "turkiye", "1q2w3e4r", "qwerty123", "password1" };
        const string Seq = "abcdefghijklmnopqrstuvwxyz0123456789qwertyuıopasdfghjklzxcvbnm";

        static byte[] Pbkdf2(string pw, byte[] salt, int iter)
        {
            using (HMACSHA256 h = new HMACSHA256(Encoding.UTF8.GetBytes(pw)))
            {
                byte[] s = new byte[salt.Length + 4];
                Buffer.BlockCopy(salt, 0, s, 0, salt.Length);
                s[salt.Length + 3] = 1;
                byte[] u = h.ComputeHash(s);
                byte[] t = (byte[])u.Clone();
                for (int i = 1; i < iter; i++)
                {
                    u = h.ComputeHash(u);
                    for (int j = 0; j < t.Length; j++) t[j] ^= u[j];
                }
                return t;
            }
        }
        public static string ToHex(byte[] b)
        {
            return BitConverter.ToString(b).Replace("-", "").ToLowerInvariant();
        }
        static byte[] FromHex(string s)
        {
            byte[] b = new byte[s.Length / 2];
            for (int i = 0; i < b.Length; i++) b[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            return b;
        }
        public static void SetPassword(string pw)
        {
            byte[] salt = new byte[16];
            Rng.GetBytes(salt);
            Store.Set("salt", ToHex(salt));
            Store.Set("hash", ToHex(Pbkdf2(pw, salt, Iter)));
        }
        public static bool Check(string pw)
        {
            try
            {
                string h = Store.Get("hash", "");
                string got = ToHex(Pbkdf2(pw, FromHex(Store.Get("salt", "")), Iter));
                int diff = got.Length ^ h.Length;
                for (int i = 0; i < got.Length && i < h.Length; i++) diff |= got[i] ^ h[i];
                return h.Length > 0 && diff == 0;
            }
            catch { return false; }
        }

        static int RandInt(int n)
        {
            ulong lim = (4294967296UL / (ulong)n) * (ulong)n;
            byte[] b = new byte[4];
            uint v;
            do { Rng.GetBytes(b); v = BitConverter.ToUInt32(b, 0); } while (v >= lim);
            return (int)(v % (uint)n);
        }
        public static string Generate(int len, List<string> pools)
        {
            List<char> o = new List<char>();
            foreach (string p in pools) o.Add(p[RandInt(p.Length)]);
            string all = string.Concat(pools.ToArray());
            while (o.Count < len) o.Add(all[RandInt(all.Length)]);
            for (int i = o.Count - 1; i > 0; i--)
            {
                int j = RandInt(i + 1);
                char t = o[i]; o[i] = o[j]; o[j] = t;
            }
            return new string(o.ToArray());
        }

        public static Assessment Assess(string pw)
        {
            Assessment a = new Assessment();
            if (pw.Length == 0) { a.Label = "Parola girin"; a.Color = Theme.Muted; return a; }
            bool lo = false, up = false, di = false, sy = false;
            foreach (char c in pw)
            {
                if (char.IsLower(c)) lo = true;
                else if (char.IsUpper(c)) up = true;
                else if (char.IsDigit(c)) di = true;
                else sy = true;
            }
            if (!lo) a.Tips.Add("Küçük harf ekleyin.");
            if (!up) a.Tips.Add("Büyük harf ekleyin.");
            if (!di) a.Tips.Add("Rakam ekleyin.");
            if (!sy) a.Tips.Add("Sembol ekleyin (örn. ! ? # %).");
            if (pw.Length < 12) a.Tips.Add("En az 12 karakter kullanın.");
            int pool = (lo ? 26 : 0) + (up ? 26 : 0) + (di ? 10 : 0) + (sy ? 30 : 0);
            double bits = pw.Length * Math.Log(Math.Max(pool, 2), 2);
            string low = pw.ToLowerInvariant();
            if (Common.Contains(low))
            {
                bits = Math.Min(bits, 10);
                a.Tips.Insert(0, "Bu parola çok yaygın, kolayca tahmin edilir.");
            }
            if (new HashSet<char>(pw).Count <= Math.Max(2, pw.Length / 4))
            {
                bits *= 0.5;
                a.Tips.Add("Tekrar eden karakterlerden kaçının.");
            }
            for (int i = 0; i + 4 <= low.Length; i++)
            {
                string s = low.Substring(i, 4);
                char[] r = s.ToCharArray();
                Array.Reverse(r);
                if (Seq.Contains(s) || Seq.Contains(new string(r)))
                {
                    bits *= 0.7;
                    a.Tips.Add("Ardışık dizilerden (abcd, 1234) kaçının.");
                    break;
                }
            }
            a.Score = (int)Math.Min(100, bits / 80 * 100);
            if (bits < 28) { a.Label = "Çok zayıf"; a.Color = Theme.Danger; }
            else if (bits < 40) { a.Label = "Zayıf"; a.Color = Theme.Danger; }
            else if (bits < 60) { a.Label = "Orta"; a.Color = Theme.Warn; }
            else if (bits < 80) { a.Label = "Güçlü"; a.Color = Theme.Ok; }
            else { a.Label = "Çok güçlü"; a.Color = Theme.Ok; }
            return a;
        }
    }

    static class Cleaner
    {
        public static string Size(long b)
        {
            if (b >= 1073741824L) return (b / 1073741824.0).ToString("0.0") + " GB";
            if (b >= 1048576L) return (b / 1048576.0).ToString("0") + " MB";
            return (b / 1024.0).ToString("0") + " KB";
        }

        // Çalışan işlemlerin kullanmadığı RAM'i Windows'a geri verir.
        public static int TrimMemory()
        {
            int n = 0;
            foreach (Process p in Process.GetProcesses())
            {
                try
                {
                    IntPtr h = Native.OpenProcess(0x0500, false, p.Id); // SET_QUOTA | QUERY_INFORMATION
                    if (h == IntPtr.Zero) continue;
                    if (Native.EmptyWorkingSet(h)) n++;
                    Native.CloseHandle(h);
                }
                catch { }
                finally { p.Dispose(); }
            }
            return n;
        }

        // Yalnızca 24 saatten eski geçici dosyalar listelenir.
        public static List<FileInfo> FindTemp()
        {
            List<FileInfo> files = new List<FileInfo>();
            Collect(Path.GetTempPath(), files);
            Collect(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp"), files);
            return files;
        }
        static void Collect(string dir, List<FileInfo> files)
        {
            try
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    try
                    {
                        FileInfo fi = new FileInfo(f);
                        if (fi.LastWriteTimeUtc < DateTime.UtcNow.AddDays(-1)) files.Add(fi);
                    }
                    catch { }
                }
            }
            catch { }
            try
            {
                foreach (string d in Directory.GetDirectories(dir))
                {
                    if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) != 0) continue;
                    Collect(d, files);
                }
            }
            catch { }
        }
        public static long Delete(List<FileInfo> files, out int count)
        {
            long freed = 0;
            count = 0;
            foreach (FileInfo fi in files)
            {
                try
                {
                    long len = fi.Length;
                    fi.Attributes = FileAttributes.Normal;
                    fi.Delete();
                    freed += len;
                    count++;
                }
                catch { }
            }
            return freed;
        }
    }

    static class SysInfo
    {
        public static string Uptime()
        {
            TimeSpan t = TimeSpan.FromMilliseconds(Native.GetTickCount64());
            return string.Format("{0} gün {1} saat {2} dakika", t.Days, t.Hours, t.Minutes);
        }

        public static string Battery()
        {
            PowerStatus ps = SystemInformation.PowerStatus;
            if ((ps.BatteryChargeStatus & BatteryChargeStatus.NoSystemBattery) != 0) return "Pil yok (masaüstü bilgisayar)";
            if (ps.BatteryLifePercent > 1) return "Pil durumu bilinmiyor";
            return string.Format("%{0} ({1})", (int)(ps.BatteryLifePercent * 100), ps.PowerLineStatus == PowerLineStatus.Online ? "şarjda" : "pilde");
        }

        public static List<string> Startup()
        {
            List<string> r = new List<string>();
            AddRun(r, Registry.CurrentUser, "Kullanıcı");
            AddRun(r, Registry.LocalMachine, "Tüm kullanıcılar");
            try
            {
                foreach (string f in Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Startup)))
                    if (!f.EndsWith("desktop.ini", StringComparison.OrdinalIgnoreCase))
                        r.Add("[Başlangıç klasörü]  " + Path.GetFileName(f));
            }
            catch { }
            return r;
        }
        static void AddRun(List<string> r, RegistryKey root, string who)
        {
            try
            {
                using (RegistryKey k = root.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                {
                    if (k == null) return;
                    foreach (string name in k.GetValueNames())
                        r.Add(string.Format("[{0}]  {1}  ->  {2}", who, name, k.GetValue(name)));
                }
            }
            catch { }
        }

        public static string Network()
        {
            StringBuilder sb = new StringBuilder();
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up) continue;
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback || ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                sb.AppendLine(ni.Name + "  (" + ni.NetworkInterfaceType + ")");
                sb.AppendLine("  Hız: " + (ni.Speed / 1000000) + " Mbit/sn");
                foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                    if (ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        sb.AppendLine("  IP adresi: " + ip.Address);
                sb.AppendLine();
            }
            return sb.Length == 0 ? "Etkin bir ağ bağlantısı bulunamadı." : sb.ToString();
        }

        // Yalnızca ağ adı ve sinyal gücü okunur, Wi-Fi parolalarına dokunulmaz.
        public static string Wifi()
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo("netsh", "wlan show interfaces");
                psi.UseShellExecute = false; psi.RedirectStandardOutput = true; psi.CreateNoWindow = true;
                using (Process p = Process.Start(psi))
                {
                    string o = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(3000);
                    string ssid = null, sig = null;
                    foreach (string line in o.Split('\n'))
                    {
                        int i = line.IndexOf(':');
                        if (i < 0) continue;
                        string key = line.Substring(0, i).Trim(), val = line.Substring(i + 1).Trim();
                        if (key == "SSID") ssid = val;
                        else if (val.EndsWith("%")) sig = val;
                    }
                    if (ssid == null) return "Wi-Fi bağlantısı yok.";
                    return "Wi-Fi ağı: " + ssid + (sig != null ? "  (sinyal " + sig + ")" : "");
                }
            }
            catch { return "Wi-Fi bilgisi alınamadı."; }
        }

        public static string PingTest()
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                using (Ping p = new Ping())
                {
                    for (int i = 0; i < 4; i++)
                    {
                        PingReply r = p.Send("8.8.8.8", 1500);
                        sb.AppendLine(r.Status == IPStatus.Success
                            ? string.Format("Yanıt alındı: {0} ms", r.RoundtripTime)
                            : "Yanıt yok: " + r.Status);
                    }
                }
            }
            catch (Exception ex) { sb.AppendLine("Test yapılamadı: " + ex.Message); }
            return sb.ToString();
        }

        static long DirSize(string dir)
        {
            long total = 0;
            try
            {
                foreach (string f in Directory.GetFiles(dir))
                {
                    try { total += new FileInfo(f).Length; } catch { }
                }
            }
            catch { }
            try
            {
                foreach (string d in Directory.GetDirectories(dir))
                {
                    try { if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) != 0) continue; } catch { continue; }
                    total += DirSize(d);
                }
            }
            catch { }
            return total;
        }
        public static string TopFolders(string root, int count)
        {
            List<KeyValuePair<long, string>> list = new List<KeyValuePair<long, string>>();
            long loose = 0, total = 0;
            try
            {
                foreach (string f in Directory.GetFiles(root))
                {
                    try { loose += new FileInfo(f).Length; } catch { }
                }
            }
            catch { }
            try
            {
                foreach (string d in Directory.GetDirectories(root))
                {
                    try { if ((File.GetAttributes(d) & FileAttributes.ReparsePoint) != 0) continue; } catch { continue; }
                    list.Add(new KeyValuePair<long, string>(DirSize(d), Path.GetFileName(d)));
                }
            }
            catch { }
            list.Sort(delegate(KeyValuePair<long, string> a, KeyValuePair<long, string> b) { return b.Key.CompareTo(a.Key); });
            foreach (KeyValuePair<long, string> kv in list) total += kv.Key;
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Toplam: " + Cleaner.Size(total + loose));
            sb.AppendLine("Klasör dışındaki dosyalar: " + Cleaner.Size(loose));
            sb.AppendLine();
            for (int i = 0; i < list.Count && i < count; i++)
                sb.AppendLine(Cleaner.Size(list[i].Key).PadLeft(10) + "   " + list[i].Value);
            if (list.Count == 0) sb.AppendLine("Alt klasör bulunamadı.");
            return sb.ToString();
        }
    }

    class MainForm : Form
    {
        Panel host;
        readonly Dictionary<string, Button> nav = new Dictionary<string, Button>();
        string previousLogin = "";

        public MainForm()
        {
            Text = "Emr Güvenlik Sistemi";
            Font = F(10);
            ClientSize = new Size(980, 640);
            MinimumSize = new Size(860, 560);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Bg;
            ShowLogin();
        }

        // ---------- yardımcılar
        static Font F(float size, FontStyle style) { return new Font("Segoe UI", size, style); }
        static Font F(float size) { return F(size, FontStyle.Regular); }
        static Label Lbl(string text, Font font, Color color, int maxW)
        {
            Label l = new Label();
            l.Text = text; l.Font = font; l.ForeColor = color; l.AutoSize = true;
            if (maxW > 0) l.MaximumSize = new Size(maxW, 0);
            l.Margin = new Padding(0, 0, 0, 8);
            return l;
        }
        static Label Lbl(string text, Font font, Color color) { return Lbl(text, font, color, 0); }
        static void Say(Label l, string text, Color c) { l.Text = text; l.ForeColor = c; }
        static TextBox Box(int w, bool pw)
        {
            TextBox b = new TextBox();
            b.Width = w; b.Font = F(11); b.UseSystemPasswordChar = pw;
            b.Margin = new Padding(0, 0, 0, 10);
            return b;
        }
        static TextBox Area(int w, int h)
        {
            TextBox b = new TextBox();
            b.Multiline = true; b.ReadOnly = true; b.ScrollBars = ScrollBars.Vertical;
            b.Font = new Font("Consolas", 9.5f); b.BackColor = Color.White;
            b.Width = w; b.Height = h; b.Margin = new Padding(0, 0, 0, 12);
            return b;
        }
        static Button Btn(string text, Color bg)
        {
            Button b = new Button();
            b.Text = text; b.BackColor = bg; b.ForeColor = bg == Theme.Line ? Theme.Text : Color.White;
            b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 0;
            b.Font = F(10, FontStyle.Bold); b.AutoSize = true; b.Padding = new Padding(10, 4, 10, 4);
            b.Cursor = Cursors.Hand; b.Margin = new Padding(0, 0, 10, 0);
            return b;
        }
        static FlowLayoutPanel Row(params Control[] items)
        {
            FlowLayoutPanel r = new FlowLayoutPanel();
            r.FlowDirection = FlowDirection.LeftToRight; r.AutoSize = true; r.WrapContents = false;
            r.Margin = new Padding(0, 0, 0, 10);
            r.Controls.AddRange(items);
            return r;
        }
        static FlowLayoutPanel NewPage(string title, string sub)
        {
            FlowLayoutPanel p = new FlowLayoutPanel();
            p.Dock = DockStyle.Fill; p.FlowDirection = FlowDirection.TopDown; p.WrapContents = false;
            p.AutoScroll = true; p.Padding = new Padding(28); p.BackColor = Theme.Bg;
            p.Controls.Add(Lbl(title, F(20, FontStyle.Bold), Theme.Text));
            p.Controls.Add(Lbl(sub, F(10), Theme.Muted, 660));
            return p;
        }

        static readonly string[] Protected = { "system", "idle", "smss", "csrss", "wininit", "winlogon", "services", "lsass", "svchost", "dwm", "explorer" };

        // Uzun işleri arka planda çalıştırır, pencere donmaz.
        static void RunBg(Func<string> work, Action<string> done)
        {
            BackgroundWorker w = new BackgroundWorker();
            w.DoWork += delegate(object snd, DoWorkEventArgs a) { a.Result = work(); };
            w.RunWorkerCompleted += delegate(object snd, RunWorkerCompletedEventArgs a)
            {
                done(a.Error != null ? "Hata: " + a.Error.Message : (string)a.Result);
                w.Dispose();
            };
            w.RunWorkerAsync();
        }
        static void Launch(string what)
        {
            try { Process.Start(what); }
            catch { MessageBox.Show("Bu araç açılamadı.", "Emr Güvenlik"); }
        }

        // ---------- giriş
        void ShowLogin()
        {
            Controls.Clear();
            bool first = Store.Get("hash", "") == "";
            Panel root = new Panel();
            root.Dock = DockStyle.Fill;
            Panel box = new Panel();
            box.Size = new Size(380, first ? 430 : 340);
            box.BackColor = Color.White;
            FlowLayoutPanel f = new FlowLayoutPanel();
            f.Dock = DockStyle.Fill; f.FlowDirection = FlowDirection.TopDown; f.WrapContents = false;
            f.Padding = new Padding(30);

            f.Controls.Add(Lbl("Emr Güvenlik Sistemi", F(17, FontStyle.Bold), Theme.Text));
            f.Controls.Add(Lbl(first ? "İlk kullanım: bir giriş parolası belirleyin." : "Devam etmek için parolanızı girin.",
                F(10), Theme.Muted, 310));
            f.Controls.Add(Lbl("Parola", F(10), Theme.Text));
            TextBox p1 = Box(310, true);
            f.Controls.Add(p1);
            TextBox p2 = null;
            if (first)
            {
                f.Controls.Add(Lbl("Parolayı tekrarla", F(10), Theme.Text));
                p2 = Box(310, true);
                f.Controls.Add(p2);
            }
            Label msg = Lbl("", F(10), Theme.Danger, 310);
            f.Controls.Add(msg);
            Button go = Btn(first ? "Kaydet ve gir" : "Giriş yap", Theme.Accent);
            go.Width = 310;
            f.Controls.Add(go);
            box.Controls.Add(f);
            root.Controls.Add(box);
            root.Resize += delegate
            {
                box.Location = new Point(Math.Max(0, (root.Width - box.Width) / 2), Math.Max(10, (root.Height - box.Height) / 2));
            };
            Controls.Add(root);
            AcceptButton = go;
            box.Location = new Point(Math.Max(0, (ClientSize.Width - box.Width) / 2), Math.Max(10, (ClientSize.Height - box.Height) / 2));

            go.Click += delegate
            {
                string pw = p1.Text;
                if (first)
                {
                    if (pw.Length < Security.MinLen) { Say(msg, string.Format("Parola en az {0} karakter olmalı.", Security.MinLen), Theme.Danger); return; }
                    if (pw != p2.Text) { Say(msg, "Parolalar eşleşmiyor.", Theme.Danger); return; }
                    Security.SetPassword(pw);
                    Store.Log("Parola oluşturuldu.");
                    EnterApp();
                    return;
                }
                long until;
                long.TryParse(Store.Get("lock", "0"), out until);
                long waitSec = (until - DateTime.UtcNow.Ticks) / TimeSpan.TicksPerSecond;
                if (waitSec > 0) { Say(msg, string.Format("Çok fazla hatalı deneme. {0} sn bekleyin.", waitSec + 1), Theme.Danger); return; }
                if (Security.Check(pw)) { Store.Set("fails", "0"); EnterApp(); return; }
                int fails;
                int.TryParse(Store.Get("fails", "0"), out fails);
                fails++;
                int total;
                int.TryParse(Store.Get("total", "0"), out total);
                Store.Set("total", (total + 1).ToString());
                Store.Log(string.Format("Hatalı giriş denemesi ({0}/5).", fails));
                if (fails >= 5)
                {
                    Store.Set("fails", "0");
                    Store.Set("lock", (DateTime.UtcNow.Ticks + 30 * TimeSpan.TicksPerSecond).ToString());
                    Store.Log("Giriş geçici olarak kilitlendi.");
                    Say(msg, "Giriş 30 saniye kilitlendi.", Theme.Danger);
                }
                else
                {
                    Store.Set("fails", fails.ToString());
                    Say(msg, string.Format("Parola yanlış. Kalan hak: {0}", 5 - fails), Theme.Danger);
                }
                p1.Clear();
            };
            p1.Focus();
        }

        void EnterApp()
        {
            previousLogin = Store.Get("last", "Bu ilk girişiniz");
            Store.Set("last", DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss"));
            Store.Log("Başarılı giriş.");
            AcceptButton = null;
            ShowShell();
            Go("home");
        }

        // ---------- ana iskelet
        void ShowShell()
        {
            Controls.Clear();
            nav.Clear();
            host = new Panel();
            host.Dock = DockStyle.Fill;
            Panel side = new Panel();
            side.Dock = DockStyle.Left; side.Width = 220; side.BackColor = Theme.Side;

            FlowLayoutPanel list = new FlowLayoutPanel();
            list.Dock = DockStyle.Fill; list.FlowDirection = FlowDirection.TopDown; list.WrapContents = false;
            list.Padding = new Padding(0, 20, 0, 0);
            list.AutoScroll = true;
            list.Controls.Add(Lbl("Emr Güvenlik", F(15, FontStyle.Bold), Color.White));
            list.Controls[0].Margin = new Padding(20, 0, 0, 16);

            string[,] items = {
                { "home", "Genel durum" }, { "ram", "RAM temizle" }, { "temp", "Geçici dosyalar" },
                { "proc", "İşlemler" }, { "startup", "Başlangıç programları" }, { "disk", "Disk analizi" },
                { "net", "Ağ bilgisi" }, { "tools", "Hızlı araçlar" },
                { "pass", "Parola araçları" }, { "hash", "Dosya doğrulama" }, { "log", "Olay günlüğü" },
                { "set", "Ayarlar" } };
            for (int i = 0; i < items.GetLength(0); i++)
            {
                string key = items[i, 0];
                Button b = NavButton(items[i, 1], Theme.SideText);
                b.Click += delegate { Go(key); };
                nav[key] = b;
                list.Controls.Add(b);
            }
            Button quit = NavButton("Oturumu kapat", ColorTranslator.FromHtml("#F4B4AE"));
            quit.Dock = DockStyle.Bottom;
            quit.Click += delegate { Store.Log("Çıkış yapıldı."); ShowLogin(); };

            side.Controls.Add(list);
            side.Controls.Add(quit);
            Controls.Add(host);
            Controls.Add(side);
        }
        static Button NavButton(string text, Color fore)
        {
            Button b = new Button();
            b.Text = text; b.Size = new Size(220, 36); b.Margin = new Padding(0);
            b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderSize = 0;
            b.FlatAppearance.MouseOverBackColor = Theme.SideHover;
            b.BackColor = Theme.Side; b.ForeColor = fore; b.Font = F(11);
            b.TextAlign = ContentAlignment.MiddleLeft; b.Padding = new Padding(16, 0, 0, 0);
            b.Cursor = Cursors.Hand;
            return b;
        }

        void Go(string key)
        {
            foreach (KeyValuePair<string, Button> kv in nav)
            {
                bool active = kv.Key == key;
                kv.Value.BackColor = active ? Theme.SideActive : Theme.Side;
                kv.Value.ForeColor = active ? Color.White : Theme.SideText;
            }
            while (host.Controls.Count > 0) host.Controls[0].Dispose();
            Control page;
            switch (key)
            {
                case "ram": page = PageRam(); break;
                case "temp": page = PageTemp(); break;
                case "proc": page = PageProcesses(); break;
                case "startup": page = PageStartup(); break;
                case "disk": page = PageDisk(); break;
                case "net": page = PageNet(); break;
                case "tools": page = PageTools(); break;
                case "pass": page = PagePassword(); break;
                case "hash": page = PageHash(); break;
                case "log": page = PageLog(); break;
                case "set": page = PageSettings(); break;
                default: page = PageHome(); break;
            }
            host.Controls.Add(page);
        }

        // ---------- sayfalar
        string[] LastEvents(int n)
        {
            string[] all = Store.ReadLog();
            List<string> r = new List<string>();
            for (int i = all.Length - 1; i >= 0 && r.Count < n; i--) r.Add(all[i]);
            return r.ToArray();
        }

        string RamText()
        {
            Native.MemStatus m = Native.Status();
            return string.Format("Kullanılan RAM: {0} / {1}  (%{2})", Cleaner.Size((long)(m.TotalPhys - m.AvailPhys)), Cleaner.Size((long)m.TotalPhys), m.Load);
        }

        Control PageHome()
        {
            FlowLayoutPanel p = NewPage("Genel durum", "Güvenlik ve bilgisayar özeti.");
            int total;
            int.TryParse(Store.Get("total", "0"), out total);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Önceki giriş: " + previousLogin);
            sb.AppendLine("Toplam hatalı deneme: " + total);
            sb.AppendLine();
            sb.AppendLine("Bilgisayar: " + Environment.MachineName);
            sb.AppendLine("Kullanıcı: " + Environment.UserName);
            sb.AppendLine("Windows: " + Environment.OSVersion.VersionString + (Environment.Is64BitOperatingSystem ? " (64 bit)" : " (32 bit)"));
            sb.AppendLine("İşlemci çekirdeği: " + Environment.ProcessorCount);
            sb.AppendLine(RamText());
            sb.AppendLine("Açık kalma süresi: " + SysInfo.Uptime());
            sb.AppendLine("Pil: " + SysInfo.Battery());
            foreach (DriveInfo d in DriveInfo.GetDrives())
            {
                try
                {
                    if (d.DriveType == DriveType.Fixed && d.IsReady)
                        sb.AppendLine(string.Format("Disk {0}  {1} boş / {2}", d.Name, Cleaner.Size(d.AvailableFreeSpace), Cleaner.Size(d.TotalSize)));
                }
                catch { }
            }
            TextBox info = Area(660, 240);
            info.Text = sb.ToString();
            p.Controls.Add(info);
            p.Controls.Add(Lbl("Son olaylar", F(12, FontStyle.Bold), Theme.Text));
            TextBox ev = Area(660, 110);
            ev.Text = string.Join("\r\n", LastEvents(5));
            p.Controls.Add(ev);
            return p;
        }

        Control PageRam()
        {
            FlowLayoutPanel p = NewPage("RAM temizle",
                "Çalışan programların boşta tuttuğu belleği Windows'a geri verir. Etki geçicidir, program ihtiyaç duydukça belleği yeniden alır.");
            Label ramLbl = Lbl(RamText(), F(11, FontStyle.Bold), Theme.Text);
            Label msg = Lbl("", F(10), Theme.Ok, 660);
            TextBox top = Area(660, 230);
            Action refresh = delegate
            {
                ramLbl.Text = RamText();
                List<KeyValuePair<long, string>> procs = new List<KeyValuePair<long, string>>();
                foreach (Process pr in Process.GetProcesses())
                {
                    try { procs.Add(new KeyValuePair<long, string>(pr.WorkingSet64, pr.ProcessName)); }
                    catch { }
                    finally { pr.Dispose(); }
                }
                procs.Sort(delegate(KeyValuePair<long, string> a, KeyValuePair<long, string> b) { return b.Key.CompareTo(a.Key); });
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < procs.Count && i < 10; i++)
                    sb.AppendLine(procs[i].Value.PadRight(30) + Cleaner.Size(procs[i].Key));
                top.Text = sb.ToString();
            };
            Button clean = Btn("RAM'i temizle", Theme.Accent);
            Button again = Btn("Yenile", Theme.Line);
            clean.Click += delegate
            {
                Cursor = Cursors.WaitCursor;
                try
                {
                    long before = (long)Native.Status().AvailPhys;
                    int n = Cleaner.TrimMemory();
                    System.Threading.Thread.Sleep(600);
                    long freed = (long)Native.Status().AvailPhys - before;
                    Say(msg, freed > 0 ? string.Format("{0} işlem düzenlendi, yaklaşık {1} boşaltıldı.", n, Cleaner.Size(freed))
                                       : string.Format("{0} işlem düzenlendi, belirgin bir fark yok.", n), Theme.Ok);
                    Store.Log("RAM temizlendi.");
                }
                finally { Cursor = Cursors.Default; }
                refresh();
            };
            again.Click += delegate { refresh(); };
            p.Controls.Add(ramLbl);
            p.Controls.Add(Row(clean, again));
            p.Controls.Add(msg);
            p.Controls.Add(Lbl("En çok RAM kullanan 10 program", F(12, FontStyle.Bold), Theme.Text));
            p.Controls.Add(top);
            refresh();
            return p;
        }

        Control PageTemp()
        {
            FlowLayoutPanel p = NewPage("Geçici dosyalar",
                "Kullanıcı ve Windows geçici klasörlerindeki 24 saatten eski dosyaları bulur. Kullanımda olan dosyalar atlanır. Windows klasörünün tamamı için programı yönetici olarak çalıştırın.");
            Label msg = Lbl("", F(11, FontStyle.Bold), Theme.Text, 660);
            List<FileInfo> found = new List<FileInfo>();
            Button scan = Btn("Tara", Theme.Accent);
            Button clean = Btn("Temizle", Theme.Danger);
            clean.Enabled = false;
            scan.Click += delegate
            {
                Cursor = Cursors.WaitCursor;
                try
                {
                    found = Cleaner.FindTemp();
                    long size = 0;
                    foreach (FileInfo fi in found) size += fi.Length;
                    Say(msg, string.Format("{0} dosya, toplam {1} temizlenebilir.", found.Count, Cleaner.Size(size)), Theme.Text);
                    clean.Enabled = found.Count > 0;
                }
                finally { Cursor = Cursors.Default; }
            };
            clean.Click += delegate
            {
                if (MessageBox.Show(string.Format("{0} geçici dosya silinecek. Devam edilsin mi?", found.Count), "Geçici dosyaları temizle",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
                Cursor = Cursors.WaitCursor;
                try
                {
                    int count;
                    long freed = Cleaner.Delete(found, out count);
                    Say(msg, string.Format("{0} dosya silindi, {1} yer açıldı.", count, Cleaner.Size(freed)), Theme.Ok);
                    Store.Log(string.Format("Geçici dosyalar temizlendi: {0} dosya.", count));
                    clean.Enabled = false;
                }
                finally { Cursor = Cursors.Default; }
            };
            p.Controls.Add(Row(scan, clean));
            p.Controls.Add(msg);
            return p;
        }

        Control PageProcesses()
        {
            FlowLayoutPanel p = NewPage("İşlemler", "Çalışan programları görün ve takılan bir programı kapatın. Kaydedilmemiş veriler kaybolabilir.");
            ListView lv = new ListView();
            lv.View = View.Details; lv.FullRowSelect = true; lv.GridLines = true; lv.MultiSelect = false;
            lv.Size = new Size(660, 330); lv.Margin = new Padding(0, 0, 0, 10);
            lv.Columns.Add("Program", 330); lv.Columns.Add("PID", 80); lv.Columns.Add("RAM", 120);
            Label msg = Lbl("", F(10), Theme.Ok, 660);
            Action refresh = delegate
            {
                List<ListViewItem> items = new List<ListViewItem>();
                foreach (Process pr in Process.GetProcesses())
                {
                    try
                    {
                        ListViewItem it = new ListViewItem(new string[] { pr.ProcessName, pr.Id.ToString(), Cleaner.Size(pr.WorkingSet64) });
                        it.Tag = pr.WorkingSet64;
                        items.Add(it);
                    }
                    catch { }
                    finally { pr.Dispose(); }
                }
                items.Sort(delegate(ListViewItem x, ListViewItem y) { return ((long)y.Tag).CompareTo((long)x.Tag); });
                lv.BeginUpdate();
                lv.Items.Clear();
                lv.Items.AddRange(items.ToArray());
                lv.EndUpdate();
            };
            Button again = Btn("Yenile", Theme.Line);
            Button kill = Btn("Seçili programı kapat", Theme.Danger);
            again.Click += delegate { refresh(); };
            kill.Click += delegate
            {
                if (lv.SelectedItems.Count == 0) { Say(msg, "Önce listeden bir program seçin.", Theme.Danger); return; }
                string name = lv.SelectedItems[0].SubItems[0].Text;
                int pid = int.Parse(lv.SelectedItems[0].SubItems[1].Text);
                if (pid == Process.GetCurrentProcess().Id || Array.IndexOf(Protected, name.ToLowerInvariant()) >= 0)
                {
                    Say(msg, "Bu sistem programı kapatılamaz.", Theme.Danger);
                    return;
                }
                if (MessageBox.Show(string.Format("\"{0}\" kapatılsın mı? Kaydedilmemiş veriler kaybolabilir.", name), "Programı kapat",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                try
                {
                    using (Process target = Process.GetProcessById(pid)) target.Kill();
                    Store.Log("Program kapatıldı: " + name);
                    Say(msg, name + " kapatıldı.", Theme.Ok);
                }
                catch (Exception ex) { Say(msg, "Kapatılamadı: " + ex.Message, Theme.Danger); }
                refresh();
            };
            p.Controls.Add(lv);
            p.Controls.Add(Row(again, kill));
            p.Controls.Add(msg);
            refresh();
            return p;
        }

        Control PageStartup()
        {
            FlowLayoutPanel p = NewPage("Başlangıç programları",
                "Windows açılırken otomatik başlayan programlar. Kapatmak için Görev Yöneticisi'nin Başlangıç sekmesini kullanın.");
            List<string> list = SysInfo.Startup();
            TextBox area = Area(660, 330);
            area.Text = list.Count == 0 ? "Kayıtlı başlangıç programı bulunamadı." : string.Join("\r\n", list.ToArray());
            Button tm = Btn("Görev Yöneticisi'ni aç", Theme.Accent);
            tm.Click += delegate { Launch("taskmgr"); };
            p.Controls.Add(area);
            p.Controls.Add(Row(tm));
            return p;
        }

        Control PageDisk()
        {
            FlowLayoutPanel p = NewPage("Disk analizi",
                "Seçtiğiniz klasördeki en büyük alt klasörleri bulur. Büyük klasörlerde birkaç dakika sürebilir.");
            TextBox folder = Box(660, false);
            folder.Text = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            TextBox area = Area(660, 300);
            Button browse = Btn("Klasör seç", Theme.Line);
            Button scan = Btn("Analiz et", Theme.Accent);
            browse.Click += delegate
            {
                using (FolderBrowserDialog d = new FolderBrowserDialog())
                {
                    d.SelectedPath = folder.Text;
                    if (d.ShowDialog() == DialogResult.OK) folder.Text = d.SelectedPath;
                }
            };
            scan.Click += delegate
            {
                string root = folder.Text.Trim();
                if (!Directory.Exists(root)) { area.Text = "Klasör bulunamadı."; return; }
                scan.Enabled = false;
                area.Text = "Taranıyor...";
                RunBg(delegate { return SysInfo.TopFolders(root, 15); },
                      delegate(string result)
                      {
                          if (area.IsDisposed) return;
                          area.Text = result;
                          scan.Enabled = true;
                      });
            };
            p.Controls.Add(folder);
            p.Controls.Add(Row(browse, scan));
            p.Controls.Add(area);
            return p;
        }

        Control PageNet()
        {
            FlowLayoutPanel p = NewPage("Ağ bilgisi", "Etkin bağlantılarınız ve internet erişim testi. Wi-Fi parolaları gösterilmez.");
            TextBox area = Area(660, 320);
            Button load = Btn("Yenile", Theme.Line);
            Button test = Btn("İnternet testi", Theme.Accent);
            Action refresh = delegate
            {
                area.Text = "Okunuyor...";
                RunBg(delegate { return SysInfo.Network() + "\r\n" + SysInfo.Wifi(); },
                      delegate(string result) { if (!area.IsDisposed) area.Text = result; });
            };
            load.Click += delegate { refresh(); };
            test.Click += delegate
            {
                area.Text = "8.8.8.8 adresine test gönderiliyor...";
                RunBg(delegate { return SysInfo.PingTest(); },
                      delegate(string result) { if (!area.IsDisposed) area.Text = "İnternet testi (8.8.8.8):\r\n" + result; });
            };
            p.Controls.Add(Row(load, test));
            p.Controls.Add(area);
            refresh();
            return p;
        }

        Control PageTools()
        {
            FlowLayoutPanel p = NewPage("Hızlı araçlar", "Sık kullanılan Windows araçlarını tek tıkla açın.");
            string[,] tools = {
                { "Görev Yöneticisi", "taskmgr" }, { "Disk Temizleme", "cleanmgr" }, { "Aygıt Yöneticisi", "devmgmt.msc" },
                { "Ağ bağlantıları", "ncpa.cpl" }, { "Windows Güvenliği", "windowsdefender:" }, { "Sistem bilgisi", "msinfo32" } };
            for (int i = 0; i < tools.GetLength(0); i++)
            {
                string cmd = tools[i, 1];
                Button b = Btn(tools[i, 0], Theme.Line);
                b.AutoSize = false;
                b.Size = new Size(260, 38);
                b.Margin = new Padding(0, 0, 0, 8);
                b.Click += delegate { Launch(cmd); };
                p.Controls.Add(b);
            }
            return p;
        }

        Control PagePassword()
        {
            FlowLayoutPanel p = NewPage("Parola araçları", "Parolanız bu bilgisayardan dışarı çıkmaz.");
            p.Controls.Add(Lbl("Parolanızı denetleyin", F(11, FontStyle.Bold), Theme.Text));
            TextBox chk = Box(660, true);
            CheckBox show = new CheckBox();
            show.Text = "Parolayı göster"; show.AutoSize = true; show.Margin = new Padding(0, 0, 0, 8);
            show.CheckedChanged += delegate { chk.UseSystemPasswordChar = !show.Checked; };
            Panel track = new Panel();
            track.Size = new Size(660, 10); track.BackColor = Theme.Line; track.Margin = new Padding(0, 0, 0, 8);
            Panel fill = new Panel();
            fill.Height = 10; fill.Width = 0; fill.Left = 0; fill.Top = 0;
            track.Controls.Add(fill);
            Label verdict = Lbl("", F(11, FontStyle.Bold), Theme.Muted);
            Label tips = Lbl("", F(10), Theme.Muted, 660);
            chk.TextChanged += delegate
            {
                Assessment a = Security.Assess(chk.Text);
                fill.Width = track.Width * a.Score / 100;
                fill.BackColor = a.Color;
                verdict.Text = a.Label; verdict.ForeColor = a.Color;
                tips.Text = a.Tips.Count == 0 ? "" : "• " + string.Join("\r\n• ", a.Tips.ToArray());
            };
            p.Controls.Add(chk); p.Controls.Add(show); p.Controls.Add(track); p.Controls.Add(verdict); p.Controls.Add(tips);

            p.Controls.Add(Lbl("Parola üretin", F(11, FontStyle.Bold), Theme.Text));
            Label lenLbl = Lbl("Uzunluk: 16", F(10), Theme.Text);
            TrackBar len = new TrackBar();
            len.Minimum = 8; len.Maximum = 64; len.Value = 16; len.TickFrequency = 8; len.Width = 420;
            len.ValueChanged += delegate { lenLbl.Text = "Uzunluk: " + len.Value; };
            CheckBox cLo = new CheckBox(), cUp = new CheckBox(), cDi = new CheckBox(), cSy = new CheckBox();
            CheckBox[] cs = { cLo, cUp, cDi, cSy };
            string[] names = { "Küçük harf", "Büyük harf", "Rakam", "Sembol" };
            for (int i = 0; i < cs.Length; i++) { cs[i].Text = names[i]; cs[i].Checked = true; cs[i].AutoSize = true; }
            TextBox outBox = Box(660, false);
            outBox.ReadOnly = true; outBox.Font = new Font("Consolas", 12);
            Label genMsg = Lbl("", F(10), Theme.Ok, 660);
            Button gen = Btn("Parola üret", Theme.Accent);
            Button copy = Btn("Kopyala", Theme.Line);
            Action make = delegate
            {
                List<string> pools = new List<string>();
                if (cLo.Checked) pools.Add("abcdefghijklmnopqrstuvwxyz");
                if (cUp.Checked) pools.Add("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
                if (cDi.Checked) pools.Add("0123456789");
                if (cSy.Checked) pools.Add("!@#$%&*?-_+=");
                if (pools.Count == 0) { Say(genMsg, "En az bir karakter türü seçin.", Theme.Danger); return; }
                outBox.Text = Security.Generate(len.Value, pools);
                Say(genMsg, "Güç: " + Security.Assess(outBox.Text).Label, Theme.Ok);
            };
            gen.Click += delegate { make(); };
            copy.Click += delegate
            {
                string copied = outBox.Text;
                if (copied.Length == 0) return;
                try
                {
                    Clipboard.SetText(copied);
                    Say(genMsg, "Kopyalandı. Pano 30 saniye sonra temizlenecek.", Theme.Ok);
                    System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
                    t.Interval = 30000;
                    t.Tick += delegate
                    {
                        t.Stop(); t.Dispose();
                        try { if (Clipboard.GetText() == copied) Clipboard.Clear(); } catch { }
                    };
                    t.Start();
                }
                catch { Say(genMsg, "Kopyalanamadı.", Theme.Danger); }
            };
            p.Controls.Add(Row(lenLbl, len));
            p.Controls.Add(Row(cs));
            p.Controls.Add(outBox);
            p.Controls.Add(Row(gen, copy));
            p.Controls.Add(genMsg);
            make();
            return p;
        }

        Control PageHash()
        {
            FlowLayoutPanel p = NewPage("Dosya doğrulama",
                "İndirdiğiniz dosyanın değiştirilip değiştirilmediğini SHA-256 ile kontrol edin.");
            Label msg = Lbl("", F(11, FontStyle.Bold), Theme.Text, 660);
            TextBox hash = Box(660, false);
            hash.ReadOnly = true; hash.Font = new Font("Consolas", 10);
            TextBox expected = Box(660, false);
            expected.Font = new Font("Consolas", 10);
            Action compare = delegate
            {
                if (hash.Text.Length == 0 || expected.Text.Trim().Length == 0) return;
                bool same = string.Equals(hash.Text, expected.Text.Trim(), StringComparison.OrdinalIgnoreCase);
                Say(msg, same ? "Eşleşiyor: dosya değişmemiş." : "Eşleşmiyor: dosya değiştirilmiş olabilir!", same ? Theme.Ok : Theme.Danger);
            };
            Button pick = Btn("Dosya seç", Theme.Accent);
            pick.Click += delegate
            {
                using (OpenFileDialog d = new OpenFileDialog())
                {
                    if (d.ShowDialog() != DialogResult.OK) return;
                    Cursor = Cursors.WaitCursor;
                    try
                    {
                        using (FileStream fs = File.OpenRead(d.FileName))
                        using (SHA256 sha = SHA256.Create())
                            hash.Text = Security.ToHex(sha.ComputeHash(fs));
                        Say(msg, "Hash hesaplandı.", Theme.Ok);
                        Store.Log("Dosya hash'i hesaplandı: " + Path.GetFileName(d.FileName));
                        compare();
                    }
                    catch (Exception ex) { Say(msg, "Dosya okunamadı: " + ex.Message, Theme.Danger); }
                    finally { Cursor = Cursors.Default; }
                }
            };
            expected.TextChanged += delegate { compare(); };
            p.Controls.Add(Row(pick));
            p.Controls.Add(Lbl("Dosyanın SHA-256 değeri", F(10), Theme.Muted));
            p.Controls.Add(hash);
            p.Controls.Add(Lbl("Yayıncının verdiği değer (isteğe bağlı)", F(10), Theme.Muted));
            p.Controls.Add(expected);
            p.Controls.Add(msg);
            return p;
        }

        Control PageLog()
        {
            FlowLayoutPanel p = NewPage("Olay günlüğü", "Girişler, hatalı denemeler ve işlemler.");
            TextBox area = Area(660, 380);
            string[] lines = Store.ReadLog();
            Array.Reverse(lines);
            area.Text = lines.Length == 0 ? "Henüz kayıtlı olay yok." : string.Join("\r\n", lines);
            Button clear = Btn("Günlüğü temizle", Theme.Danger);
            clear.Click += delegate
            {
                if (MessageBox.Show("Tüm olay kayıtları silinecek. Emin misiniz?", "Günlüğü temizle",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
                Store.ClearLog();
                area.Text = "Henüz kayıtlı olay yok.";
            };
            p.Controls.Add(area);
            p.Controls.Add(clear);
            return p;
        }

        Control PageSettings()
        {
            FlowLayoutPanel p = NewPage("Ayarlar", "Giriş parolanızı değiştirin.");
            TextBox o = Box(320, true), n = Box(320, true), a = Box(320, true);
            Label msg = Lbl("", F(10), Theme.Danger, 660);
            Button save = Btn("Parolayı değiştir", Theme.Accent);
            save.Click += delegate
            {
                if (!Security.Check(o.Text)) { Say(msg, "Mevcut parola yanlış.", Theme.Danger); return; }
                if (n.Text.Length < Security.MinLen) { Say(msg, string.Format("Yeni parola en az {0} karakter olmalı.", Security.MinLen), Theme.Danger); return; }
                if (n.Text != a.Text) { Say(msg, "Yeni parolalar eşleşmiyor.", Theme.Danger); return; }
                Security.SetPassword(n.Text);
                Store.Log("Parola değiştirildi.");
                o.Clear(); n.Clear(); a.Clear();
                Say(msg, "Parola değiştirildi.", Theme.Ok);
            };
            p.Controls.Add(Lbl("Mevcut parola", F(10), Theme.Text)); p.Controls.Add(o);
            p.Controls.Add(Lbl("Yeni parola", F(10), Theme.Text)); p.Controls.Add(n);
            p.Controls.Add(Lbl("Yeni parolayı tekrarla", F(10), Theme.Text)); p.Controls.Add(a);
            p.Controls.Add(Row(save));
            p.Controls.Add(msg);
            return p;
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            try { Native.SetProcessDPIAware(); } catch { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Store.Load();
            Application.Run(new MainForm());
        }
    }
}

@echo off
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
"%CSC%" /nologo /target:winexe /optimize+ /codepage:65001 /out:EmrGuvenlik.exe /reference:System.dll,System.Core.dll,System.Drawing.dll,System.Windows.Forms.dll EmrGuvenlik.cs
if errorlevel 1 (
  echo Derleme basarisiz.
  pause
  exit /b 1
)
echo EmrGuvenlik.exe hazir.
pause
